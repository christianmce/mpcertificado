<?php

echo '<h3>Hubo un error con tu pago</h3>';
echo '<p>Porfavor intentalo de nuevo</p>';
echo '<a href="../">Regresar e internarolo de nuevo</a>';

?>
